import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Test 
{
	public static void main(String args[])
	{
		Configuration cfg = new Configuration();
		cfg.configure(); //to load configuration files
		
		SessionFactory factory = cfg.buildSessionFactory();
		
		Session session = factory.openSession();
		//DML
		
		Transaction tran = session.beginTransaction();
		
		Employee emp = new Employee(123, "ramya", 28000);
		session.save(emp); //insert, ORM
		
		tran.commit();
//		session.close();
//		factory.close();
	}
}
